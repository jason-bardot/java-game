package ProjetLemmings;

public class ExploMapComponent extends AbsMapComponent {
	public ExploMapComponent() {
		this.isDestructible = true;
		this.isBlocking = true;
		this.isJumpable = false;
		this.isKiller = false;
		this.idBloc = 7;
	}
	
	@Override
	public boolean action(Lemming lem) {
		Map M = Map.getInstance();
		AbsMapComponent[][] map = M.getmap();
		int x = lem.getPosX();
		int y = lem.getPosY()+lem.getDirection().getValue();
		for(int i=-2;i<3;i++) {
		    for(int j=-2;j<3;j++) {
		        if(((x+i >= 0 && y+j >=0))&&(x+i <= M.getX_max() && y+j <= M.getY_max())) {
		            if(map[x+i][y+j].getIdBloc() == 0||map[x+i][y+j].isDestructible()){
		            	map[x+i][y+j] = MapComponentFactory.CreateBloc(8);
		            	M.addTempBloc(new Coordonnee(x+i,y+j));
		            }
		        }
		    }
		}
		return true;
	}

}
