package ProjetLemmings;

public enum GameEvent {
	lemSpawn{
		Lemming lem;
		@Override
		public void Init(Lemming lem) {
			this.lem = lem;
		}
		
		public Lemming getLem() {
			return lem;
		}
	},lemDeath{
		Lemming lem;
		@Override
		public void Init(Lemming lem) {
			this.lem = lem;			
		}
		
		public Lemming getLem() {
			return lem;
		}
	};
	
	abstract public void Init(Lemming lem);
	abstract public Lemming getLem();
}