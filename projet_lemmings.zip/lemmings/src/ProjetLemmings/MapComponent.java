package ProjetLemmings;

public class MapComponent extends AbsMapComponent{
	
	public MapComponent(boolean isDestructible, boolean isBlocking, boolean isJumpable, boolean isKiller, int idBloc) {
		this.isDestructible = isDestructible;
		this.isBlocking = isBlocking;
		this.isJumpable = isJumpable;
		this.isKiller = isKiller;
		this.idBloc = idBloc;
	}

	@Override
	public boolean action(Lemming lem) {
		return false;
	}
}