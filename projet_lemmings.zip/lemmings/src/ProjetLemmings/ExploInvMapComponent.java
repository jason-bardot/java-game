package ProjetLemmings;

import java.util.Random;

public class ExploInvMapComponent extends AbsMapComponent{
	public ExploInvMapComponent() {
		this.isDestructible = true;
		this.isBlocking = true;
		this.isJumpable = false;
		this.isKiller = false;
		this.idBloc = 8;
	}
	
	public boolean action(Lemming lem) {
		Random r = new Random();
		Map M = Map.getInstance();
		AbsMapComponent[][] map = M.getmap();
		int x , y;
		x = lem.getPosX();
		y = lem.getPosY() + lem.getDirection().getValue();
		map[x][y] = MapComponentFactory.CreateBloc(3);
		for(int i=-2;i<3;i++) {
			for(int j=-2;j<3;j++) {
				 if(((x+i >= 0 && y+j >=0))&&(x+i <= M.getX_max() && y+j <= M.getY_max())) {
					if(map[x+i][y+j].getIdBloc() == 0) {
						boolean rand = r.nextBoolean();
						if(rand && !(((i==1 && j==0) || (i==-1 && j==0)) ||((i==0 && j==1) || (i==0 && j==-1)))){
							map[x+i][y+j] = MapComponentFactory.CreateBloc(3);
						}
					}
				}
			}
		}
		return true;
	}

}
