

package ProjetLemmings;

import java.awt.Color;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

import HUD.TeteHaute;

public class MyJFrame implements ActionListener{
	static public final int camMarge = 8;
	private final boolean CameraLibre = false;
	JFrame frame = null;
	MyJPanel panel = null;
	Timer timer = null;
	Map map = null;
	MyJButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10, binfo;
	boolean loop = false;
	String OS;
	
	public MyJFrame(){
		frame = new JFrame("Lemmings");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setFocusable(true);
		frame.setResizable(false);
		
		
		
		//frame.setSize(1366,768); // resolution de JASON
		OS = System.getProperty("os.name").toLowerCase();
		
		// Pour eviter le bug fullScreen ubuntu
		if(OS.indexOf("win") > 0){
			frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			frame.setUndecorated(true);
		}else{ // On va dire que c'est linux ou mac sinon ...
			frame.setSize(Toolkit.getDefaultToolkit().getScreenSize());
			frame.setUndecorated(true);
		} 
	}
	
	public void DisplayMainMenu(){
		frame.getContentPane().removeAll();
		JPanel panel = new JPanel();
		panel.setBackground(new Color(200,200,200));
		
		
		
		
		
		// On affiche le menu principal
		panel.setLayout(null);
		JLabel label0 = new JLabel("text");
		label0.setText("<html>Commencer par les niveaux \"TUTO\"</html>");
		label0.setBounds(720, 20, 100, 60);
		label0.setOpaque(true);
		 
		JLabel label1 = new JLabel("text");
		label1.setText("<html>Comment ça marche ?<br><br>"
				+ "  -Pour jouer vous devez appuier sur les boutons numérotés de gauches "
				+ "et passer la souris par dessus les personnages, pour les transformers."
				+ "<br>Le but est de faire passer un certain nombre de personnage dans la porte d'arriver</html>");
		label1.setBounds(20,260, 300,140);  
		label1.setOpaque(true);
		
		frame.setContentPane(panel);
		
		
		
		b1 = new MyJButton("map 1",20,20,this);
		b2 = new MyJButton("map 2",20,100,this);
		b3 = new MyJButton("tuto 1",400,20,this);
		b4 = new MyJButton("tuto 2",400,100,this);
		b5 = new MyJButton("tuto 3",400,180,this);
		b6 = new MyJButton("tuto 4",400,260,this);
		b7 = new MyJButton("tuto 5",400,340,this);
		b8 = new MyJButton("tuto 6",400,420,this);
		b9 = new MyJButton("tuto 7",400,500,this);
		b10 = new MyJButton("quitter",20,180,this);
		
		panel.add(b1);
		panel.add(b2);
		panel.add(b3);
		panel.add(b4);
		panel.add(b5);
		panel.add(b6);
		panel.add(b7);
		panel.add(b8);
		panel.add(b9);
		panel.add(b10);
		panel.add(label0);
		panel.add(label1);
		frame.setContentPane(panel);
		frame.setVisible(true);
	}
	
	public void DisplayScreen(String mapPath){
		frame.getContentPane().removeAll();
		panel = new MyJPanel();
		frame.setContentPane(panel);
		frame.setVisible(true);
		TeteHaute.CreationHUD(panel);
		TeteHaute.getInstance().Chargement();
		
		
		Map.NouvelleMap(mapPath);
		panel.Init(frame.getHeight(), frame.getWidth());
		
		frame.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				//System.out.println("Y : "+panel.getCamY() + " | width : " + frame.getWidth() + " || " + "X : "+ panel.getCamX() + " | width : " + frame.getHeight());
				super.keyPressed(e);
				if(e.getKeyCode() == KeyEvent.VK_LEFT || e.getKeyCode() == KeyEvent.VK_Q) {
					if(panel.getCamY()-(MyJPanel.blocSize*camMarge) < 0 || CameraLibre)	// on ne s'eloigne pas trop de la map
						panel.setCamY(panel.getCamY()+MyJPanel.blocSize);
				} else if(e.getKeyCode() == KeyEvent.VK_UP || e.getKeyCode() == KeyEvent.VK_Z) {
					if(panel.getCamX()-(MyJPanel.blocSize*camMarge) < 0 || CameraLibre)
						panel.setCamX(panel.getCamX()+MyJPanel.blocSize);
				} else if(e.getKeyCode() == KeyEvent.VK_DOWN || e.getKeyCode() == KeyEvent.VK_S) {
					//System.out.println(((map.getX_max()*MyJPanel.blocSize))-frame.getHeight());
					if(panel.getCamX()*-1 < (((Map.getInstance().getX_max()+camMarge)*MyJPanel.blocSize))-frame.getHeight() || CameraLibre)
						panel.setCamX(panel.getCamX()-MyJPanel.blocSize );
				} else if(e.getKeyCode() == KeyEvent.VK_RIGHT || e.getKeyCode() == KeyEvent.VK_D) {
					if(panel.getCamY()*-1 < (((Map.getInstance().getY_max()+camMarge+1)*MyJPanel.blocSize))-frame.getWidth() || CameraLibre)
						panel.setCamY(panel.getCamY()-MyJPanel.blocSize);
				} else if(e.getKeyCode() == KeyEvent.VK_ESCAPE){
					timer.stop();
					DisplayMainMenu();
				}
			}
		});
		
		timer = new Timer(100, this);
		//timer.setInitialDelay(pause);
		timer.start();
	}

	public void actionPerformed(ActionEvent ae) {
		Object src = ae.getSource();
		if(src == b1){
			this.DisplayScreen("map/map_jason.txt");
		}else if(src == b2){
			this.DisplayScreen("map/map_axel.txt");
		}else if(src == b3){
			this.DisplayScreen("map/map_creuseurH.txt");
		}else if(src == b4){
			this.DisplayScreen("map/map_creuseurV.txt");
		}else if(src == b5){
			this.DisplayScreen("map/map_grimpeur.txt");
		}else if(src == b6){
			this.DisplayScreen("map/map_parachutiste.txt");
		}else if(src == b7){
			this.DisplayScreen("map/map_bloqueur.txt");
		}else if(src == b8){
			this.DisplayScreen("map/map_bombeur.txt");
		}else if(src == b9){
			this.DisplayScreen("map/map_charpentier.txt");
		}else if(src == b10){
			Quitter();
		}else if(src == timer)
		{
			int bla = Map.getInstance().loop(frame);
			if(bla == 1)
			{
				JOptionPane.showMessageDialog( frame, "Vous avez perdu", "Defaite", JOptionPane.INFORMATION_MESSAGE);
				timer.stop();
				DisplayMainMenu();
			}else if(bla == 2)
				// On laisse le choix au joueur de quitter quand il le souhaite
				JOptionPane.showMessageDialog( frame, "Vous avez gagne (echap pour retourner au menu)", "Victoire",JOptionPane.INFORMATION_MESSAGE);
			
			panel.repaint();
		}
	}
	
	public void Quitter(){
		frame.dispose();
		System.exit(0);
	}
}