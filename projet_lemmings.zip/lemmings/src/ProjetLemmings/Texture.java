package ProjetLemmings;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.imageio.ImageIO;

// Conteneur a texture
public class Texture {
	public final static Texture t = new Texture();
	public final static int bgSizeX = 512, bgSizeY = 256;
	
	private final String cheminDossier = "ressource/image/";
	private final String cheminTextLemming = "ressource/textureLemming/";
	private final String prefixe = "mapComp";
	private final String suffixe = ".png";
	private final int nbTextures = 14;
	private final int nbLemsTypes = 8;
	private final int nbTexturesLems = 6;
	private ArrayList<BufferedImage> imgs;
	private BufferedImage[][] textureLems;
	private BufferedImage backGround;
	private int animation = 0;
	private int iAnimation = 0;
	private int lemAnim = 0;
	
	private Texture() {
		imgs = new ArrayList<BufferedImage>();
		textureLems = new BufferedImage[nbLemsTypes][nbTexturesLems];
	}
	
	public boolean Chargement() {
		// Remplissage du tableau de texture
		for(int i = 1;i <= nbTextures;i++) {
			try {
				imgs.add(ImageIO.read(new File(cheminDossier+prefixe+i+suffixe)));
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
		}
		for(int i = 0;i < nbLemsTypes;i++){
			for(int i2 = 1;i2 <= nbTexturesLems;i2++){
				try {
					textureLems[i][i2-1] = ImageIO.read(new File(cheminTextLemming+i+i2+suffixe));
				} catch (IOException e) {
					e.printStackTrace();
					return false;
				}
			}
		}
		try { // On charge le backGround
			backGround = ImageIO.read(new File(cheminDossier+"background"+".jpg"));
		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public BufferedImage getTexture(int index) {
		if(index <= nbTextures)
			if(index == 1 || index == 10)
				return imgs.get((index-1)+animation);
			else
				return imgs.get(index-1);
		else 
			return null;
	}
	
	public BufferedImage getTextLemming(int i,int i2) {
		return textureLems[i][i2+lemAnim];
	}
	
	public BufferedImage getBackground() {
		return backGround;
	}
	
	public void incrementeAnimation() {
		iAnimation++;
		if(iAnimation >= 2)
		{
			iAnimation = 0;
			animation++;
			lemAnim++;
			if(animation > 3)
				animation = 0;
			if(lemAnim > 2)
				lemAnim = 0;
		}
	}
}
