package ProjetLemmings;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JComponent;

import HUD.TeteHaute;

public class Lemming extends JComponent implements MouseListener{
	private int posX;
	private int posY;
	private int chute;
	private Direction direction;
	private int deplacement;
	private boolean vivant;
	private int capacite;
	private StateType type;
	
	public Lemming(int posX, int posY) {
		this.posX = posX;
		this.posY = posY;
		this.setSize(MyJPanel.blocSize,MyJPanel.blocSize);
		this.setLocation(posY*MyJPanel.blocSize, posX*MyJPanel.blocSize);
		this.addMouseListener(this);
		this.type = StateType.StateNormal;
		this.vivant = true;
		this.direction = Direction.Droite;
		this.deplacement = 1;
		this.capacite = 0;
		this.chute=0;
	}
	
	@Override
	public void paint(Graphics g){
		int i = Integer.parseInt(type.toString());
		int i2 = 0;
		if(direction == direction.Gauche)
			i2 = 3;
		g.drawImage(Texture.t.getTextLemming(i, i2), 0 , 0 , null);
	}
	
	public int Comportement(){
		Map M = Map.getInstance();
		AbsMapComponent[][] map = M.getmap();
		if((posX < 0 || posX >= M.getX_max()) || (map[posX][posY].isKiller() || !vivant)) {
			// Le lemming est sorti de la map ou il est dans un bloc mortel
			return -1;
		}	
		if(map[posX][posY].getIdBloc()==5) {
			// Le lemming est arrive
			return 1;
		}
		if(capacite == 0 && type.getDefaultCap() != 0){
			// Le lemming redevient normal
			type.finCap(this);
		}
		if(deplacement < 1){
			// le deplacement coute 2 tours
			deplacement++;
		}else {
			deplacement=0;
			if(!map[posX+1][posY].isBlocking())	{
				// Rien en dessous
				type.chute(this);
			}else {
				// Quelque chose en dessous
				if(chute >= 5) {
					// Meurt de la chute
					return -1;
				}
				chute = 0;
				int nextY = posY+getDirection().getValue();
				if(nextY >= 0 && nextY <= M.getY_max()) {
					//vérif si la case suivante existe
					if(!map[posX][nextY].isBlocking()){
						// Pas d'obstacle
						type.marcher(this);
					}else{
						// Si il y a un obstacle
						if(map[posX][nextY].action(this)) {
							return 0;
						}
						if((!map[posX-1][nextY].isBlocking() && !map[posX-1][posY].isBlocking()) && (map[posX][nextY].isJumpable())){ 
							// Mini saut
							type.sauter(this);
						}else{									
							type.collision(this);
						}
					}
				}else
					StateType.StateNormal.collision(this);
			}
		}	
		return 0;
	}

	public void setVivant(boolean vivant) {
		this.vivant = vivant;
	}

	public void changeDirection() {
		if(direction.getValue() == 1)
			direction = Direction.Gauche;
		else
			direction = Direction.Droite;
	}
	
	public void changeType(StateType type) {
		this.type = type;
		type.init(this);
	}
	
	public void initType() {
		this.capacite = type.getDefaultCap();
	}
	
	public void decrementCap() {
		capacite--;
	}
	
	// Getters Setters
	public Direction getDirection() {
		return direction;
	}
	
	public int getCapacite() {
		return capacite;
	}

	public int getChute() {
		return chute;
	}

	public void setChute(int chute) {
		this.chute = chute;
	}
	
	public void setPosX(int posX) {
		this.posX = posX;
		this.setLocation(posY*MyJPanel.blocSize, posX*MyJPanel.blocSize);
	}
	
	public void setPosY(int posY) {
		this.posY = posY;
		this.setLocation(posY*MyJPanel.blocSize, posX*MyJPanel.blocSize);
	}

	public int getPosX() {
		return posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setDirection(Direction direction) {
		this.direction = direction;
	}

	public void mouseClicked(MouseEvent arg0) {
		this.changeType(TeteHaute.getInstance().getTypeLemming());
	}

	public void mouseEntered(MouseEvent arg0) {
		this.changeType(TeteHaute.getInstance().getTypeLemming());
	}
	
	public void mouseExited(MouseEvent arg0) {}
	public void mousePressed(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}


}