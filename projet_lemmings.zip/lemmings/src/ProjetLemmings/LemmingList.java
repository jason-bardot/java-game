package ProjetLemmings;

import java.util.Iterator;
import java.util.Vector;

public class LemmingList implements Iterable<Lemming>{
	int index = 0;
	Vector<Lemming> lemmings;
	boolean dead = false;
	
	public LemmingList() {
		lemmings = new Vector<Lemming>();
	}
	
	public void add(Lemming lem) {
		GameObserver.NotifySpawn(lem);
		lemmings.add(lem);
	}
	
	public void killCurrent() {
		GameObserver.NotifyDead(lemmings.get(index - 1));
		lemmings.remove(index - 1);
		dead = true;
	}
	
	public Lemming get(int i) {
		return lemmings.get(i);
	}
	
	public Lemming getCurrent() {
		return lemmings.get(index);
	}
	
	public Lemming getLast() {
		return this.get(this.size() - 1);
	}
	
	public int size() {
		return lemmings.size();
	}
	
	public void reset() {
		index = 0;
	}
	
	public void erase() {
		lemmings.clear();
	}

	public Iterator<Lemming> iterator() {
		return new Iterator<Lemming>() {
			public Lemming next() {
				Lemming lem = lemmings.get(index);
				if(dead == true)
					dead = false;
				else
					index++;
				return lem;
			}
			public boolean hasNext() {
				if(index >= lemmings.size())
				{
					index = 0;
					return false;
				}
				return true;
			}
		};
	}
}
