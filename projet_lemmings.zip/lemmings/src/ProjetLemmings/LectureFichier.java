package ProjetLemmings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LectureFichier {
	static private LectureFichier lf = null;
	BufferedReader br = null;
	
	static public void CharcherFichier(String chemin){
		if(lf == null)
			lf = new LectureFichier(chemin);
		else {
			close();
			try {
				lf.br = new BufferedReader(new FileReader(new File(chemin)));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
	
	private LectureFichier(String chemin){
		try {
			br = new BufferedReader(new FileReader(new File(chemin)));
		} catch (FileNotFoundException e) {
			System.err.println("LectureFichier.java - constructor(syso): fichier non trouv�");
		}
	}
	
	static public String LireLigne(){
		String ret = null;
		try{
			ret = lf.br.readLine();
		}catch(Exception ex){
			System.err.println("LectureFichier.java - LireLigne(syso): " + ex.getMessage());
		}
		return ret;
	}
	
	static public void close(){
		try {
			lf.br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
