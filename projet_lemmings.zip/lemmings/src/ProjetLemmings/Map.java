package ProjetLemmings;

import java.util.ArrayList;
import javax.swing.JFrame;
import HUD.TeteHaute;

public class Map {
	static private Map instanceMap;
	private AbsMapComponent map[][];
	private ArrayList<Coordonnee> tempBlocs;
	private LemmingList lems;
	private int x_max;
	private int y_max;
	private int lem_max;
	private int freq;
	private int lemQuota;
	private boolean fin = false;
	private int x_spawner;
	private int y_spawner;
	private int iLoop_spawn = 0;
	private int iLemmings_spawn = 0;
	private int lem_dead = 0,lem_winner = 0;
	private boolean tmp = false;
	
	private Map(){
		lems = new LemmingList();
		tempBlocs = new ArrayList<Coordonnee>();
	}
	
	static public void NouvelleMap(String chemin) {
		instanceMap = new Map();
		instanceMap.ChargerMap(chemin);
	}
	
	static public Map getInstance() {
		return instanceMap;
	}

	private void ChargerMap(String chemin){
		LectureFichier.CharcherFichier(chemin);
		String s = LectureFichier.LireLigne();
		x_max =  Integer.parseInt(s.split(" ")[0])-1;
		y_max =  Integer.parseInt(s.split(" ")[1])-1;
		map = new AbsMapComponent[x_max+1][y_max+1];
		for(int i = 0;i <= x_max; i++) {
			s = LectureFichier.LireLigne();
			for(int l = 0;l <= y_max; l++) {
				int trait = Integer.parseInt(s.split(" ")[l]);
				map[i][l] = MapComponentFactory.CreateBloc(trait);
				if(trait == 1) {
					x_spawner = i;
					y_spawner = l;
				}
			}
		}
		s = LectureFichier.LireLigne();
		lem_max = Integer.parseInt(s);
		s = LectureFichier.LireLigne();
		freq = Integer.parseInt(s);
		s = LectureFichier.LireLigne();
		lemQuota = Integer.parseInt(s);
		iLoop_spawn = freq;
		TeteHaute.getInstance().setLemQuota(lemQuota); 
		TeteHaute.getInstance().setLemMax(lem_max);
		LectureFichier.close();
	}
	
	public int loop(JFrame p){
		// Spawn Lemmings
		if(++iLoop_spawn >= freq && iLemmings_spawn < lem_max){
			lems.add(new Lemming(x_spawner,y_spawner));
			p.add(lems.getLast());
			iLemmings_spawn++;
			iLoop_spawn = 0;
		}
		tmp =!tempBlocs.isEmpty();
		TeteHaute.getInstance().updateData(iLemmings_spawn, lem_dead, lem_winner);

		for(Lemming l : lems){
			// Comportement Lemmings
			int ret = l.Comportement();
			if(ret == -1){
				// le lemming est mort
				p.remove(l);
				lems.killCurrent();
				lem_dead++;
			}else if(ret == 1) {
				// le lemming est arrivé
				p.remove(l);
				lems.killCurrent();
				lem_winner++;
			}
		}
		if(tmp) {
			//il existe des blocs temporaires
			for(Coordonnee c : tempBlocs){
				map[c.getX()][c.getY()] = MapComponentFactory.CreateBloc(0);
			}
			tempBlocs = new ArrayList<Coordonnee>();
			tmp = false;
		}

		if(lem_dead == lem_max && !fin){
			// Est ce que le joueur à perdu / gagner ?
			return 1;
		}else if(lem_winner == lemQuota && !fin){
			fin = true;
			return 2;
		}else
			return 0;
	}
	
	public AbsMapComponent[][] getmap() {
		return this.map;
	}

	public int getX_max() {
		return x_max;
	}

	public int getY_max() {
		return y_max;
	}

	public LemmingList getLemmings() {
		return lems;
	}
	
	public void addTempBloc(Coordonnee tb) {
		tempBlocs.add(tb);
	}
}
