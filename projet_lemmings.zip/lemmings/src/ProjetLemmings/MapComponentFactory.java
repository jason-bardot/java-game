package ProjetLemmings;

public abstract class MapComponentFactory {
	static public AbsMapComponent CreateBloc(int v){
		if(v < 0)//Bloc teleporteur
			return new TeleporteurMapComponent(v);
		if(v == 0)//Bloc vide
			return new MapComponent(false,false,false,false,0);
		if(v == 1)//Bloc Spawner
			return new MapComponent(false,true,true,false,1);
		if(v == 2)//Bloc Arrive
			return new MapComponent(false,false,false,false,5);
		if(v == 3)//Bloc destructible simple
			return new MapComponent(true,true,true,false,6);
		if(v == 4)//Bloc destructible explosif
			return new ExploMapComponent();
		if(v == 5)//Bloc destructible exposif inverse
			return new ExploInvMapComponent();
		if(v == 6)//Bloc indestructible simple
			return new MapComponent(false,true,true,false,9);
		if(v == 7)//Bloc indestructible lethal(lave)
			return new MapComponent(false,false,false,true,10);
		if(v == 8)//Bloc temporaire emmit par TNT 
			return new MapComponent(false,false,false,true,10);
		if(v == 9)//Bloc temporaire emmit par lemmings explosifs
			return new MapComponent(false,false,false,false,10);
		if(v == 10)//bloc bloquant
			return new MapComponent(false,true,false,false,0);
		return null;
	}
}
