package ProjetLemmings;

import java.awt.Color;
import java.awt.Graphics;
import javax.swing.JPanel;

@SuppressWarnings("serial")
public class MyJPanel extends JPanel{
	public final static int blocSize = 32;
	private final boolean displayGrille = false;
	private LemmingList lemmings;
	private int mapX = 10,mapY = 10;
	private int camX = 0 , camY = 0;
	private int bgRepeatX , bgRepeatY;
	
	
	public MyJPanel(){
		super();
		this.setBackground(new Color(255,255,255));
		this.setLayout(null);
		Texture.t.Chargement();
	}
	
	public int getCamX() {
		return camX;
	}

	public void setCamX(int camX) {
		this.camX = camX;
	}

	public int getCamY() {
		return camY;
	}

	public void setCamY(int camY) {
		this.camY = camY;
	}
	
	public void Init(int winHeight,int winWidth)
	{
		Map m = Map.getInstance();
		this.mapX = m.getX_max();
		this.mapY = m.getY_max();
		this.lemmings = m.getLemmings();
		
		bgRepeatX = genBGRepeat(mapX, winHeight, Texture.bgSizeX)+1;
		bgRepeatY = genBGRepeat(mapY, winWidth, Texture.bgSizeY)+1;
	}
	
	private int genBGRepeat(int mapSize,int winSize,int textureSize) {
		int ret = 0,cMap = -1-MyJFrame.camMarge*MyJPanel.blocSize;
		mapSize = mapSize * MyJPanel.blocSize;
		while( cMap < mapSize || cMap < winSize) {
			cMap += textureSize;
			ret++;
		}
		return ret;
	}
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		AbsMapComponent map[][] = Map.getInstance().getmap();
		
		// Dessin background
		// Le background doit recouvrir la zone de deplacement de la cam�ra ET la map
		//g.drawImage(t.getBackground(), -1000, -1000, null);
		for(int x = 0;x < bgRepeatX;x++)
			for(int y = 0;y < bgRepeatY;y++)
				g.drawImage(Texture.t.getBackground(),camY - blocSize*MyJFrame.camMarge + (y*Texture.bgSizeY) ,camX - blocSize*MyJFrame.camMarge + (x*Texture.bgSizeX), null);
		// Dessin map :
		for(int x=0;x <= mapX;x++)
		{
			for(int y=0;y <= mapY;y++)
			{
				if(map[x][y].getIdBloc()>0)
					g.drawImage(Texture.t.getTexture(map[x][y].getIdBloc()), camY + (y*blocSize) , camX + (x*blocSize), null);
				else if(map[x][y].getIdBloc() < 0) // Pour les t�l�porteurs
					g.drawImage(Texture.t.getTexture(14), camY + (y*blocSize) , camX + (x*blocSize), null);
				if(displayGrille)
				{
					g.setColor(new Color(200,200,200));
					g.drawRect(camY + (y*blocSize),camX + (x*blocSize),blocSize,blocSize);
				}
			}
		}
		for(Lemming l : lemmings){
			l.setLocation(camY + (l.getPosY()*blocSize), camX + (l.getPosX()*blocSize));
		}
		// Delimitation map :
		g.setColor(new Color(0,0,0));
		g.drawLine(camY, camX, camY, camX+((mapX+1)*blocSize));
		g.drawLine(camY, camX, camY+((mapY+1)*blocSize), camX);
		g.drawLine(camY, camX+((mapX+1)*blocSize), camY+((mapY+1)*blocSize), camX+((mapX+1)*blocSize));
		g.drawLine(camY+((mapY+1)*blocSize), camX, camY+((mapY+1)*blocSize), camX+((mapX+1)*blocSize));
		Texture.t.incrementeAnimation();
	}
}