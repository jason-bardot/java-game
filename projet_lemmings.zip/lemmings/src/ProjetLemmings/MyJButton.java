/**
 * MyJButton.java
 * @description pour l'instant inutilis� ... peut etre a recycler plus tard pour faire des boutons plus classe ^^
 * @author Le meilleur lemmings
 * @date 22/09/2017
 * @version 0.1
 */

package ProjetLemmings;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;

@SuppressWarnings("serial")
public class MyJButton extends JButton implements MouseListener{ // AbstractButton
	MyJFrame frame;
	
	public MyJButton(String text,int posX,int posY,MyJFrame frame){
		super(text);
		this.frame = frame;
		this.addMouseListener(this);
		this.addActionListener(frame);
		this.setBackground(new Color(0,0,0));
		this.setForeground(new Color(255,255,255));
		this.setSize(300, 60);
		this.setLocation(posX, posY);
	}
	
	public void mouseClicked(MouseEvent e){
		System.out.println("clique");
	}

	public void mouseEntered(MouseEvent arg0) {
		this.setBackground(new Color(255,0,0));
		this.setForeground(new Color(255,255,255));
	}

	public void mouseExited(MouseEvent arg0) {
		this.setBackground(new Color(0,0,0));
		this.setForeground(new Color(255,255,255));
	}

	public void mousePressed(MouseEvent arg0) {
	}

	public void mouseReleased(MouseEvent arg0) {
	}
}