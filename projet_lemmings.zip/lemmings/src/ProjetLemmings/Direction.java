package ProjetLemmings;

public enum Direction {
	Droite(1), Gauche(-1);
	private int value;
	private Direction(int v) {
		this.value = v;
	}
	public int getValue() {
	    return value;
	}
}