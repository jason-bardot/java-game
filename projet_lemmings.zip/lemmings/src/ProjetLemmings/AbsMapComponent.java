package ProjetLemmings;

public abstract class AbsMapComponent {
	protected boolean isDestructible , isBlocking , isKiller , isJumpable;
	protected int idBloc;
	
	abstract public boolean action(Lemming lem); //renvoie vrai si le bloc coûte l'action du lemming

	public boolean isKiller() {
		return isKiller;
	}
	
	public boolean isDestructible() {
		return isDestructible;
	}

	public boolean isBlocking() {
		return isBlocking;
	}

	public boolean isJumpable() {
		return isJumpable;
	}

	public int getIdBloc() {
		return idBloc;
	}
}