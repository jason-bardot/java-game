package ProjetLemmings;

import java.util.ArrayList;

public class GameObserver {
	public enum Event{lemSpawn,lemDeath};
	static public GameObserver obs = new GameObserver();
	private ArrayList<Lemming> spawn;
	private ArrayList<Lemming> dead;
	
	private GameObserver() {
		spawn = new ArrayList<Lemming>();
		dead = new ArrayList<Lemming>();
	}
	
	static public void NotifyDead(Lemming lem) {
		obs.dead.add(lem);
	}
	
	static public void NotifySpawn(Lemming lem) {
		obs.spawn.add(lem);
	}
	
	static public ArrayList<Lemming> getDead(){
		return obs.dead;
	}
	
	static public ArrayList<Lemming> getSpawn(){
		return obs.spawn;
	}
	
	static public void clearEvent() {
		obs.spawn.clear();
		obs.dead.clear();
	}
}