package ProjetLemmings;

import java.util.Random;

public class TeleporteurMapComponent extends AbsMapComponent{
	public TeleporteurMapComponent(int idBloc) {
		this.isDestructible = true;
		this.isBlocking = true;
		this.isJumpable = false;
		this.isKiller = false;
		this.idBloc = idBloc;
	}
	
	public boolean action(Lemming lem) {
		int yMax = Map.getInstance().getY_max();
		lem.setPosX(((-idBloc)/(yMax+1))-1);
		lem.setPosY(((-idBloc)%(yMax+1))-1);
		
		return true;
	}
}
