package ProjetLemmings;

import java.awt.Color;
import java.util.ArrayList;

public enum StateType {
	StateNormal{
		public void init(Lemming lem) {
			if(lem.getCapacite() == -1) {
				Map M = Map.getInstance();
				AbsMapComponent[][] map = M.getmap();
				map[lem.getPosX()][lem.getPosY()] = MapComponentFactory.CreateBloc(0);
			}
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			lem.setPosX(lem.getPosX() + 1);
			lem.setChute(lem.getChute() + 1);
		}
		@Override
		protected void marcher(Lemming lem) {
			lem.setPosY(lem.getPosY()+lem.getDirection().getValue());
		}
		@Override
		protected void sauter(Lemming lem) {
			lem.setPosY(lem.getPosY() + lem.getDirection().getValue());
			lem.setPosX(lem.getPosX() - 1);
		}
		@Override
		protected void collision(Lemming lem) {
			lem.changeDirection();
		}
		@Override
		protected void finCap(Lemming lem) {
		}
		@Override
		protected int getDefaultCap() {
			return 1;
		}
		
		public String toString() {
			return "0";
		}
	},
	StateCreuseurHorizontal{
		public void init(Lemming lem) {
			StateType.StateNormal.init(lem);
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			StateType.StateNormal.chute(lem);
		}
		@Override
		protected void marcher(Lemming lem) {
			if(lem.getCapacite() == getDefaultCap())
				StateType.StateNormal.marcher(lem);
			else
				lem.changeType(StateType.StateNormal);
			
		}
		@Override
		protected void sauter(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			if(map[lem.getPosX()][lem.getPosY()+lem.getDirection().getValue()].isDestructible()) {
				map[lem.getPosX()][lem.getPosY()+lem.getDirection().getValue()]= MapComponentFactory.CreateBloc(0);
				lem.decrementCap();
				StateType.StateNormal.marcher(lem);
			}else {
				StateType.StateNormal.sauter(lem);
			}
		}
		@Override
		protected void collision(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			if(map[lem.getPosX()][lem.getPosY()+lem.getDirection().getValue()].isDestructible()) {
				map[lem.getPosX()][lem.getPosY()+lem.getDirection().getValue()]= MapComponentFactory.CreateBloc(0);
				lem.decrementCap();
				StateType.StateNormal.marcher(lem);
			}else {

				StateType.StateNormal.collision(lem);
			}
		}
		@Override
		protected void finCap(Lemming lem) {
			lem.changeType(StateType.StateNormal);
		}
		@Override
		protected int getDefaultCap() {
			return 10;
		}
		@Override
		public String toString() {
			return "1";
		}
	},
	StateCreuseurVertical{
		public void init(Lemming lem) {
			StateType.StateNormal.init(lem);
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			StateType.StateNormal.chute(lem);
		}
		@Override
		protected void marcher(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			if(map[lem.getPosX()+1][lem.getPosY()].isDestructible()) {
				map[lem.getPosX()+1][lem.getPosY()]= MapComponentFactory.CreateBloc(0);;
				lem.decrementCap();
				StateType.StateNormal.chute(lem);
			}else {
				
				if(lem.getCapacite() == getDefaultCap())
					StateType.StateNormal.marcher(lem);
				else
					lem.changeType(StateType.StateNormal);
			}
		}
		@Override
		protected void sauter(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			if(map[lem.getPosX()+1][lem.getPosY()].isDestructible()) {
				map[lem.getPosX()+1][lem.getPosY()]= MapComponentFactory.CreateBloc(0);;
				lem.decrementCap();
				StateType.StateNormal.chute(lem);
			}else {
				StateType.StateNormal.sauter(lem);
			}
		}
		@Override
		protected void collision(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			if(map[lem.getPosX()+1][lem.getPosY()].isDestructible()) {
				map[lem.getPosX()+1][lem.getPosY()]= MapComponentFactory.CreateBloc(0);;
				lem.decrementCap();
				StateType.StateNormal.chute(lem);
			}else {
				StateType.StateNormal.collision(lem);
			}
		}
		@Override
		protected void finCap(Lemming lem) {
			lem.changeType(StateType.StateNormal);
		}
		@Override
		protected int getDefaultCap() {
			return 3;
		}
		@Override
		public String toString() {
			return "2";
		}
	},
	StateGrimpeur{
		public void init(Lemming lem) {
			StateType.StateNormal.init(lem);
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			if(map[lem.getPosX()-1][lem.getPosY()].isBlocking()) {
				StateType.StateNormal.chute(lem);
				lem.decrementCap();
			}else if(map[lem.getPosX()][lem.getPosY()+lem.getDirection().getValue()].isBlocking()) {
				if(map[lem.getPosX()-1][lem.getPosY()+lem.getDirection().getValue()].isBlocking()) {
					lem.setPosX(lem.getPosX() - 1);
				}else {
					StateType.StateNormal.sauter(lem);
					lem.decrementCap();
				}
			}else {
				StateType.StateNormal.chute(lem);
			}
		}
		@Override
		protected void marcher(Lemming lem) {
			StateType.StateNormal.marcher(lem);
		}
		@Override
		protected void sauter(Lemming lem) {
			StateType.StateNormal.sauter(lem);
		}
		@Override
		protected void collision(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			if(!map[lem.getPosX()-1][lem.getPosY()].isBlocking() && map[lem.getPosX()-1][lem.getPosY()+lem.getDirection().getValue()].isBlocking()) {
				lem.setPosX(lem.getPosX() - 1);
			}else {
				StateType.StateNormal.collision(lem);
			}
			
		}
		@Override
		protected void finCap(Lemming lem) {
			lem.changeType(StateType.StateNormal);
		}
		@Override
		protected int getDefaultCap() {
			return 1;
		}
		@Override
		public String toString() {
			return "3";
		}
	},
	StateParachutiste{
		public void init(Lemming lem) {
			StateType.StateNormal.init(lem);
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			lem.setChute(0);
			StateType.StateNormal.chute(lem);
		}
		@Override
		protected void marcher(Lemming lem) {
			StateType.StateNormal.marcher(lem);
		}
		@Override
		protected void sauter(Lemming lem) {
			StateType.StateNormal.sauter(lem);
		}
		@Override
		protected void collision(Lemming lem) {
			StateType.StateNormal.collision(lem);
		}
		@Override
		protected void finCap(Lemming lem) {
			lem.changeType(StateType.StateNormal);
		}
		@Override
		protected int getDefaultCap() {
			return 0;
		}
		@Override
		public String toString() {
			return "4";
		}
	},
	StateBloqueur{
		public void init(Lemming lem) {
			StateType.StateNormal.init(lem);
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			StateType.StateNormal.chute(lem);
		}
		@Override
		protected void marcher(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			map[lem.getPosX()][lem.getPosY()] = MapComponentFactory.CreateBloc(10);
		}
		@Override
		protected void sauter(Lemming lem) {
			StateType.StateBloqueur.marcher(lem);
		}
		@Override
		protected void collision(Lemming lem) {
			StateType.StateBloqueur.marcher(lem);
		}
		@Override
		protected void finCap(Lemming lem) {
			lem.changeType(StateType.StateNormal);
		}
		@Override
		protected int getDefaultCap() {
			return -1;
		}
		@Override
		public String toString() {
			return "5";
		}
	},
	StateBombeur{
		public void init(Lemming lem) {
			StateType.StateNormal.init(lem);
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			StateType.StateNormal.chute(lem);
		}
		@Override
		protected void marcher(Lemming lem) {
			StateType.StateNormal.marcher(lem);
			lem.decrementCap();
		}
		@Override
		protected void sauter(Lemming lem) {
			StateType.StateNormal.sauter(lem);
			lem.decrementCap();
		}
		@Override
		protected void collision(Lemming lem) {
			StateType.StateNormal.collision(lem);
		}
		@Override
		protected void finCap(Lemming lem) {
			lem.changeType(StateType.StateNormal);
			//
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			int x = lem.getPosX();
			int y = lem.getPosY();
			for(int i=-2;i<3;i++) {
			    for(int j=-2;j<3;j++) {
			        if(((x+i >= 0 && y+j >=0))&&(x+i <= M.getX_max() && y+j <= M.getY_max())) {
			            if(map[x+i][y+j].getIdBloc() == 0||map[x+i][y+j].isDestructible()){
			            	map[x+i][y+j] = MapComponentFactory.CreateBloc(9);
			            	M.addTempBloc(new Coordonnee(x+i,y+j));
			            }
			        }
			    }
			}
			//
			lem.setVivant(false);
		}
		@Override
		protected int getDefaultCap() {
			return 3;
		}
		@Override
		public String toString() {
			return "6";
		}
	},
	StateCharpentier{
		public void init(Lemming lem) {
			StateType.StateNormal.init(lem);
			lem.initType();
		}
		@Override
		protected void chute(Lemming lem) {
			StateType.StateNormal.chute(lem);
		}
		@Override
		protected void marcher(Lemming lem) {
			Map M = Map.getInstance();
			AbsMapComponent[][] map = M.getmap();
			map[lem.getPosX()][lem.getPosY()+lem.getDirection().getValue()] = MapComponentFactory.CreateBloc(3);
			lem.decrementCap();
		}
		@Override
		protected void sauter(Lemming lem) {
			StateType.StateNormal.sauter(lem);
		}
		@Override
		protected void collision(Lemming lem) {
			StateType.StateNormal.collision(lem);
		}
		@Override
		protected void finCap(Lemming lem) {
			lem.changeType(StateType.StateNormal);
		}
		@Override
		protected int getDefaultCap() {
			return 3;
		}
		@Override
		public String toString() {
			return "7";
		}
	};
	public abstract void init(Lemming lem);
	public abstract String toString();
	protected abstract void chute(Lemming lem);
	protected abstract void marcher(Lemming lem );
	protected abstract void sauter(Lemming lem);
	protected abstract void collision(Lemming lem);
	protected abstract void finCap(Lemming lem);
	protected abstract int getDefaultCap();
}
