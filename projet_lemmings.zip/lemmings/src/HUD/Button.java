package HUD;

import java.awt.Color;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;

import ProjetLemmings.StateType;

public class Button extends JButton implements MouseListener{
	TeteHaute hud;
	StateType type;
	Color couleur;
	
	public Button(TeteHaute hud,StateType type,String label,int posX,int posY,int tailleX,int tailleY,Color couleur){
		super(label);
		this.hud = hud;
		this.type = type;
		this.setLocation(posX,posY);
		this.setSize(tailleX,tailleY);
		this.couleur = couleur;
		this.setForeground(new Color(255-couleur.getRed(),255-couleur.getGreen(),255-couleur.getRed()));
		this.setBackground(couleur);
		this.setMargin(new Insets(0,0,0,0));
		this.addMouseListener(this);
		this.setFocusable(false);
	}
	
	public void mouseClicked(MouseEvent arg0) {
		hud.setTypeLemming(type);
	}
	public void mouseEntered(MouseEvent arg0) {
		this.setBackground(new Color(255,255,255));
		this.setForeground(new Color(0,0,0));
	}
	public void mouseExited(MouseEvent arg0) {
		this.setBackground(couleur);
		this.setForeground(new Color(255-couleur.getRed(),255-couleur.getGreen(),255-couleur.getRed()));
	}
	public void mousePressed(MouseEvent arg0) {
	}
	public void mouseReleased(MouseEvent arg0) {
	}
}
