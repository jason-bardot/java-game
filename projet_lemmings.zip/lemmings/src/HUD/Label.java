package HUD;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;

public class Label extends JLabel{
	String value;
	
	public Label(String value){
		super(value);
		this.value = value;
		this.setForeground(new Color(255,255,255));
	}
	
	public Label(String value,int flag){
		super(value);
		this.value = value;
		this.setForeground(new Color(255,255,255));
		if(flag == 1){	// Titre
			this.setFont(new Font(this.getFont().getFontName(),Font.BOLD + Font.ITALIC,20));
		}
	}
}
