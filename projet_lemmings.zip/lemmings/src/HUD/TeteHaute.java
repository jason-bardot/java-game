package HUD;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;

import ProjetLemmings.StateType;

public class TeteHaute {
	private static TeteHaute hud;
	private JPanel panelFather,voletGauche,voletHaut;
	private JLabel label1 , label2 , label3;
	private int h , w;
	private StateType typeLemming;
	private int lemMax, lemQuota;
	
	static public void CreationHUD(JPanel panelFather) {
		hud = new TeteHaute(panelFather);
	}
	
	static public TeteHaute getInstance() {
		return hud;
	}
	
	private TeteHaute(JPanel panelFather) {
		h = panelFather.getSize().height;
		w = panelFather.getSize().width;
		this.panelFather = panelFather;
	}
	
	public void Chargement(){
		int wVolet = 55;
		int hVolet = h/2;
		int hauteurButton = hVolet / 15;
		int decalageButton = hauteurButton/2;
		typeLemming = StateType.StateNormal;
		
		voletGauche = new JPanel();
		voletGauche.setLayout(null);
		voletGauche.setBackground(new Color(80,80,80,200));
		voletGauche.setBounds(0, h*3/5, 0, 0);
		voletGauche.setSize(wVolet,hVolet-(decalageButton*8));
		voletGauche.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));
		
		voletGauche.add(new Button(this,StateType.StateCreuseurHorizontal,"1",10,decalageButton,wVolet - 20,hauteurButton,new Color(100,100,255)));
		voletGauche.add(new Button(this,StateType.StateCreuseurVertical,"2",10,decalageButton*4,wVolet - 20,hauteurButton,new Color(100,255,100)));
		voletGauche.add(new Button(this,StateType.StateGrimpeur,"3",10,decalageButton*7,wVolet - 20,hauteurButton,new Color(255,200,100)));
		voletGauche.add(new Button(this,StateType.StateParachutiste,"4",10,decalageButton*10,wVolet - 20,hauteurButton,new Color(20,20,100)));
		voletGauche.add(new Button(this,StateType.StateBloqueur,"5",10,decalageButton*13,wVolet - 20,hauteurButton,new Color(120,0,100)));
		voletGauche.add(new Button(this,StateType.StateBombeur,"6",10,decalageButton*16,wVolet - 20,hauteurButton,new Color(100,0,0)));
		voletGauche.add(new Button(this,StateType.StateCharpentier,"7",10,decalageButton*19,wVolet - 20,hauteurButton,new Color(180,90,0)));
		
		panelFather.add(voletGauche);
		
		voletHaut = new JPanel();
		label1 = new Label("Lemmings 9999/9999");
		label2 = new Label("Morts 9999/9999");
		label3 = new Label("Arrivees 9999/9999");
		voletHaut.setLayout(new FlowLayout(FlowLayout.CENTER,30,10));
		voletHaut.setBackground(new Color(80,80,80,200));
		voletHaut.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));
		
		voletHaut.add(label1);
		voletHaut.add(label2);
		voletHaut.add(label3);
		voletHaut.setSize(voletHaut.getPreferredSize());
		voletHaut.setLocation((w-voletHaut.getWidth())/2, 0);
		panelFather.add(voletHaut);
		
		JPanel voletInfo = new JPanel(); 
		voletInfo.setLayout(new BoxLayout(voletInfo,BoxLayout.Y_AXIS));
		voletInfo.add(new Label("Saisie clavier :",1));
		voletInfo.add(new Label("[Fleches directionnelle / zqsd] Pour deplacer la camera"));
		voletInfo.add(new Label("[Echap] Pour quitter"));
		voletInfo.add(new Label("Les boutons :",1));
		voletInfo.add(new Label("1 -> Creuseur"));
		voletInfo.add(new Label("2 -> Forreur"));
		voletInfo.add(new Label("3 -> Grimpeur"));
		voletInfo.add(new Label("4 -> Parachutiste"));
		voletInfo.add(new Label("5 -> Bloqueur"));
		voletInfo.add(new Label("6 -> Bombeur"));
		voletInfo.add(new Label("7 -> Charpentier"));
		voletInfo.setBackground(new Color(20,80,80,200));
		voletInfo.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));
		voletInfo.setSize(voletInfo.getPreferredSize());
		voletInfo.setLocation(w-(w/3), h-voletInfo.getHeight()-30);
		panelFather.add(voletInfo);
	}

	public void setLemMax(int lemMax) {
		this.lemMax = lemMax;
	}

	public void setLemQuota(int lemQuota) {
		this.lemQuota = lemQuota;
	}

	public StateType getTypeLemming() {
		return typeLemming;
	}
	
	public void setTypeLemming(StateType typeLemming) {
		this.typeLemming = typeLemming;
	}
	
	public void updateData(int lemSpawned , int lemDead, int lemWinner){
		label1.setText("Lemmings "+lemSpawned+"/"+lemMax);
		label2.setText("Morts "+lemDead+"/"+lemMax);
		label3.setText("Arrives " + lemWinner + "/" + lemQuota);
	}
}
