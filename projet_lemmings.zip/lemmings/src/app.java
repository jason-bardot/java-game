import ProjetLemmings.MyJFrame;

public class app {
	public static void main(String[] args) {
		MyJFrame frame = new MyJFrame();
		frame.DisplayMainMenu();
	}
}